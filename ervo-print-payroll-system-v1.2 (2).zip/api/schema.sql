-- =============================================================================
-- ERVO PRINT PAYROLL SYSTEM - MySQL / MariaDB Schema (cPanel & phpMyAdmin Ready)
-- =============================================================================
-- Cara Import di phpMyAdmin (cPanel / XAMPP / Laragon):
-- 1. Buat database baru terlebih dahulu (di cPanel > MySQL Databases, atau
--    di phpMyAdmin lokal buat database misal `ervo_payroll` utf8mb4_unicode_ci).
-- 2. Klik nama database tersebut di panel kiri phpMyAdmin.
-- 3. Buka tab "Import", pilih file schema.sql ini, lalu klik "Import / Go".
-- =============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `employees` (
  `id` VARCHAR(128) NOT NULL,
  `no_id` VARCHAR(64) DEFAULT '',
  `name` VARCHAR(255) NOT NULL,
  `division` VARCHAR(128) DEFAULT 'PRODUKSI',
  `position` VARCHAR(128) DEFAULT 'Staff',
  `pay_cycle_type` VARCHAR(32) DEFAULT 'date',
  `salary_type` VARCHAR(16) DEFAULT 'daily',
  `gapok_hari` DECIMAL(15, 2) NOT NULL DEFAULT 0,
  `gapok_bulan` DECIMAL(15, 2) NOT NULL DEFAULT 0,
  `status` VARCHAR(32) DEFAULT 'active',
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_employees_name` (`name`),
  INDEX `idx_employees_division` (`division`),
  INDEX `idx_employees_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `kasbon_records` (
  `id` VARCHAR(128) NOT NULL,
  `employee_id` VARCHAR(128) NOT NULL,
  `employee_name` VARCHAR(255) NOT NULL,
  `date` VARCHAR(32) DEFAULT '',
  `type` VARCHAR(64) DEFAULT 'kasbon',
  `total_amount` DECIMAL(15, 2) NOT NULL DEFAULT 0,
  `remaining_amount` DECIMAL(15, 2) NOT NULL DEFAULT 0,
  `status` VARCHAR(32) DEFAULT 'pending',
  `invoice_no` VARCHAR(128) DEFAULT NULL,
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_kasbon_employee` (`employee_id`),
  INDEX `idx_kasbon_status` (`status`),
  INDEX `idx_kasbon_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `kasbon_drafts` (
  `id` VARCHAR(128) NOT NULL,
  `request_number` VARCHAR(128) DEFAULT '',
  `employee_id` VARCHAR(128) NOT NULL,
  `employee_name` VARCHAR(255) NOT NULL,
  `request_date` VARCHAR(32) DEFAULT '',
  `amount` DECIMAL(15, 2) NOT NULL DEFAULT 0,
  `status` VARCHAR(32) DEFAULT 'menunggu_acc',
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_drafts_employee` (`employee_id`),
  INDEX `idx_drafts_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bonus_records` (
  `id` VARCHAR(128) NOT NULL,
  `employee_id` VARCHAR(128) NOT NULL,
  `employee_name` VARCHAR(255) NOT NULL,
  `date` VARCHAR(32) DEFAULT '',
  `type` VARCHAR(32) DEFAULT 'tunai',
  `amount` DECIMAL(15, 2) NOT NULL DEFAULT 0,
  `status` VARCHAR(32) DEFAULT 'pending',
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_bonus_employee` (`employee_id`),
  INDEX `idx_bonus_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `pengajian_sessions` (
  `id` VARCHAR(128) NOT NULL,
  `date` VARCHAR(32) NOT NULL,
  `title` VARCHAR(255) DEFAULT '',
  `total_peserta` INT NOT NULL DEFAULT 0,
  `total_ustadz` INT NOT NULL DEFAULT 0,
  `total_nominal_non_tunai` DECIMAL(15, 2) NOT NULL DEFAULT 0,
  `status` VARCHAR(32) DEFAULT 'active',
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_pengajian_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `raw_logs` (
  `id` VARCHAR(128) NOT NULL,
  `employee_name` VARCHAR(255) NOT NULL,
  `user_id` VARCHAR(64) DEFAULT '',
  `timestamp` VARCHAR(64) NOT NULL,
  `status` VARCHAR(64) DEFAULT '',
  `department` VARCHAR(128) DEFAULT '',
  `device` VARCHAR(128) DEFAULT '',
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_raw_logs_emp` (`employee_name`),
  INDEX `idx_raw_logs_ts` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `payroll_periods` (
  `id` VARCHAR(128) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `pay_cycle_filter` VARCHAR(32) DEFAULT 'all',
  `start_date` VARCHAR(32) DEFAULT '',
  `end_date` VARCHAR(32) DEFAULT '',
  `payment_date` VARCHAR(32) DEFAULT '',
  `status` VARCHAR(32) DEFAULT 'finalized',
  `total_employees` INT NOT NULL DEFAULT 0,
  `total_payout` DECIMAL(15, 2) NOT NULL DEFAULT 0,
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_periods_dates` (`start_date`, `end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `app_settings` (
  `id` VARCHAR(64) NOT NULL,
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `late_validation_overrides` (
  `id` VARCHAR(64) NOT NULL,
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `business_transactions` (
  `id` VARCHAR(128) NOT NULL,
  `date` VARCHAR(32) DEFAULT '',
  `business_unit` VARCHAR(128) NOT NULL,
  `type` VARCHAR(32) NOT NULL,
  `category` VARCHAR(128) DEFAULT '',
  `amount` DECIMAL(15, 2) NOT NULL DEFAULT 0,
  `description` TEXT,
  `payment_method` VARCHAR(128) DEFAULT '',
  `reference_no` VARCHAR(128) DEFAULT '',
  `status` VARCHAR(32) DEFAULT 'completed',
  `source` VARCHAR(64) DEFAULT 'manual',
  `source_app` VARCHAR(255) DEFAULT '',
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_biz_tx_unit` (`business_unit`),
  INDEX `idx_biz_tx_ref` (`reference_no`),
  INDEX `idx_biz_tx_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `employee_savings_records` (
  `id` VARCHAR(128) NOT NULL,
  `employee_id` VARCHAR(128) NOT NULL,
  `employee_name` VARCHAR(255) NOT NULL,
  `date` VARCHAR(32) DEFAULT '',
  `type` VARCHAR(32) NOT NULL,
  `amount` DECIMAL(15, 2) NOT NULL DEFAULT 0,
  `balance_after` DECIMAL(15, 2) NOT NULL DEFAULT 0,
  `source` VARCHAR(64) DEFAULT 'manual_deposit',
  `payroll_period_id` VARCHAR(128) DEFAULT NULL,
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_savings_employee` (`employee_id`),
  INDEX `idx_savings_period` (`payroll_period_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `app_checkpoints` (
  `id` VARCHAR(128) NOT NULL,
  `timestamp` VARCHAR(64) NOT NULL,
  `trigger_type` VARCHAR(64) DEFAULT 'manual_save',
  `description` TEXT,
  `payload_json` LONGTEXT NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_checkpoints_ts` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
