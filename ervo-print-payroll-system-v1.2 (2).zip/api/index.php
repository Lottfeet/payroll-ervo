<?php
/**
 * ERVO PRINT PAYROLL SYSTEM - PHP Backend API (cPanel Non-Node.js + phpMyAdmin)
 * Mendukung MySQL / MariaDB via PDO dan fallback penyimpanan JSON lokal.
 */

declare(strict_types=1);

@ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

// CORS headers untuk integrasi webhook ERVO STORE & ERVO SUBLIME
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-HTTP-Method-Override');

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
if (!empty($_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'])) {
    $method = strtoupper((string)$_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE']);
}

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

define('STORAGE_DIR', __DIR__ . '/storage');
define('FALLBACK_DB_FILE', STORAGE_DIR . '/ervo_database_store.json');
define('CALENDAR_SYNC_FILE', STORAGE_DIR . '/calendar_sync_store.json');

if (!is_dir(STORAGE_DIR)) {
    @mkdir(STORAGE_DIR, 0755, true);
}

$TABLE_MAP = [
    'employees' => 'employees',
    'kasbonRecords' => 'kasbon_records',
    'kasbonDrafts' => 'kasbon_drafts',
    'bonusRecords' => 'bonus_records',
    'pengajianSessions' => 'pengajian_sessions',
    'rawLogs' => 'raw_logs',
    'payrollPeriods' => 'payroll_periods',
    'appSettings' => 'app_settings',
    'lateValidationOverrides' => 'late_validation_overrides',
    'businessTransactions' => 'business_transactions',
    'employeeSavingsRecords' => 'employee_savings_records',
    'appCheckpoints' => 'app_checkpoints',
];

function sendJson($data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function getJsonBody(): array {
    $raw = file_get_contents('php://input');
    $contentLength = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    if (($raw === false || trim($raw) === '') && empty($_POST) && $contentLength > 0) {
        sendJson([
            'success' => false,
            'error' => "Ukuran data request ({$contentLength} bytes) melebihi batas post_max_size server PHP. Gunakan upload bertahap."
        ], 413);
    }
    if ($raw !== false && trim($raw) !== '') {
        $decoded = json_decode($raw, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            sendJson([
                'success' => false,
                'error' => 'Format JSON request tidak valid: ' . json_last_error_msg()
            ], 400);
        }
        if (is_array($decoded)) {
            return $decoded;
        }
    }
    return is_array($_POST) ? $_POST : [];
}

function resolveRoute(): string {
    if (isset($_GET['route']) && $_GET['route'] !== '') {
        return trim((string)$_GET['route'], '/');
    }
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
    $path = (string)(parse_url($uri, PHP_URL_PATH) ?? '');
    $pos = strpos($path, '/api/');
    if ($pos !== false) {
        return trim(substr($path, $pos + 5), '/');
    }
    return trim($path, '/');
}

// =========================================================================
// Fallback JSON Storage Helpers
// =========================================================================
function createEmptyStore(array $tableMap): array {
    $store = [];
    foreach (array_keys($tableMap) as $key) {
        $store[$key] = [];
    }
    return $store;
}

function loadFallbackStore(array $tableMap): array {
    $empty = createEmptyStore($tableMap);
    if (!file_exists(FALLBACK_DB_FILE)) {
        return $empty;
    }
    $raw = @file_get_contents(FALLBACK_DB_FILE);
    if (!$raw) {
        return $empty;
    }
    $parsed = json_decode($raw, true);
    if (!is_array($parsed)) {
        return $empty;
    }
    return array_merge($empty, $parsed);
}

function saveFallbackStore(array $store): void {
    @file_put_contents(FALLBACK_DB_FILE, json_encode($store, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
}

function loadCalendarFile(): array {
    if (file_exists(CALENDAR_SYNC_FILE)) {
        $raw = @file_get_contents(CALENDAR_SYNC_FILE);
        $parsed = $raw ? json_decode($raw, true) : null;
        if (is_array($parsed)) {
            return [
                'records' => is_array($parsed['records'] ?? null) ? $parsed['records'] : [],
                'holidays' => is_array($parsed['holidays'] ?? null) ? $parsed['holidays'] : [],
                'lastUpdated' => (string)($parsed['lastUpdated'] ?? gmdate('c')),
            ];
        }
    }
    return [
        'records' => [],
        'holidays' => [],
        'lastUpdated' => gmdate('c'),
    ];
}

function saveCalendarFile(array $data): void {
    @file_put_contents(CALENDAR_SYNC_FILE, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
}

// =========================================================================
// MySQL PDO Connection & Schema Bootstrap
// =========================================================================
$dbState = [
    'pdo' => null,
    'mysqlConfigured' => false,
    'mysqlConnected' => false,
    'employeesHasSalaryColumns' => false,
    'host' => 'localhost',
    'port' => 3306,
    'database' => 'ervo_payroll',
    'error' => null,
];

function initMysqlConnection(array &$dbState): void {
    $config = null;
    $configPath = __DIR__ . '/config.php';
    if (file_exists($configPath)) {
        $loaded = require $configPath;
        if (is_array($loaded)) {
            $config = $loaded;
        }
    }

    $host = (string)($config['DB_HOST'] ?? getenv('MYSQL_HOST') ?: 'localhost');
    $port = (int)($config['DB_PORT'] ?? getenv('MYSQL_PORT') ?: 3306);
    $dbName = (string)($config['DB_NAME'] ?? getenv('MYSQL_DATABASE') ?: '');
    $dbUser = (string)($config['DB_USER'] ?? getenv('MYSQL_USER') ?: '');
    $dbPass = (string)($config['DB_PASS'] ?? getenv('MYSQL_PASSWORD') ?: '');

    $dbState['host'] = $host;
    $dbState['port'] = $port;
    if ($dbName !== '') {
        $dbState['database'] = $dbName;
    }

    if ($dbName === '' || $dbUser === '' || $dbName === 'cpaneluser_ervo_payroll') {
        $dbState['mysqlConfigured'] = false;
        $dbState['mysqlConnected'] = false;
        $dbState['error'] = 'File api/config.php belum dikonfigurasi (menggunakan penyimpanan lokal JSON server PHP).';
        return;
    }

    $dbState['mysqlConfigured'] = true;

    if (!extension_loaded('pdo_mysql')) {
        $dbState['mysqlConnected'] = false;
        $dbState['error'] = 'Ekstensi PHP pdo_mysql belum aktif di server hosting.';
        return;
    }

    try {
        $dsn = "mysql:host={$host};port={$port};dbname={$dbName};charset=utf8mb4";
        $pdo = new PDO($dsn, $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_TIMEOUT => 5,
        ]);

        // Ensure tables exist automatically if user has CREATE privileges
        $ddlList = [
            "CREATE TABLE IF NOT EXISTS `employees` (`id` VARCHAR(128) NOT NULL PRIMARY KEY, `no_id` VARCHAR(64) DEFAULT '', `name` VARCHAR(255) NOT NULL, `division` VARCHAR(128) DEFAULT 'PRODUKSI', `position` VARCHAR(128) DEFAULT 'Staff', `pay_cycle_type` VARCHAR(32) DEFAULT 'date', `salary_type` VARCHAR(16) DEFAULT 'daily', `gapok_hari` DECIMAL(15, 2) NOT NULL DEFAULT 0, `gapok_bulan` DECIMAL(15, 2) NOT NULL DEFAULT 0, `status` VARCHAR(32) DEFAULT 'active', `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `kasbon_records` (`id` VARCHAR(128) NOT NULL PRIMARY KEY, `employee_id` VARCHAR(128) NOT NULL, `employee_name` VARCHAR(255) NOT NULL, `date` VARCHAR(32) DEFAULT '', `type` VARCHAR(64) DEFAULT 'kasbon', `total_amount` DECIMAL(15, 2) NOT NULL DEFAULT 0, `remaining_amount` DECIMAL(15, 2) NOT NULL DEFAULT 0, `status` VARCHAR(32) DEFAULT 'pending', `invoice_no` VARCHAR(128) DEFAULT NULL, `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `kasbon_drafts` (`id` VARCHAR(128) NOT NULL PRIMARY KEY, `request_number` VARCHAR(128) DEFAULT '', `employee_id` VARCHAR(128) NOT NULL, `employee_name` VARCHAR(255) NOT NULL, `request_date` VARCHAR(32) DEFAULT '', `amount` DECIMAL(15, 2) NOT NULL DEFAULT 0, `status` VARCHAR(32) DEFAULT 'menunggu_acc', `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `bonus_records` (`id` VARCHAR(128) NOT NULL PRIMARY KEY, `employee_id` VARCHAR(128) NOT NULL, `employee_name` VARCHAR(255) NOT NULL, `date` VARCHAR(32) DEFAULT '', `type` VARCHAR(32) DEFAULT 'tunai', `amount` DECIMAL(15, 2) NOT NULL DEFAULT 0, `status` VARCHAR(32) DEFAULT 'pending', `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `pengajian_sessions` (`id` VARCHAR(128) NOT NULL PRIMARY KEY, `date` VARCHAR(32) NOT NULL, `title` VARCHAR(255) DEFAULT '', `total_peserta` INT NOT NULL DEFAULT 0, `total_ustadz` INT NOT NULL DEFAULT 0, `total_nominal_non_tunai` DECIMAL(15, 2) NOT NULL DEFAULT 0, `status` VARCHAR(32) DEFAULT 'active', `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `raw_logs` (`id` VARCHAR(128) NOT NULL PRIMARY KEY, `employee_name` VARCHAR(255) NOT NULL, `user_id` VARCHAR(64) DEFAULT '', `timestamp` VARCHAR(64) NOT NULL, `status` VARCHAR(64) DEFAULT '', `department` VARCHAR(128) DEFAULT '', `device` VARCHAR(128) DEFAULT '', `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `payroll_periods` (`id` VARCHAR(128) NOT NULL PRIMARY KEY, `name` VARCHAR(255) NOT NULL, `pay_cycle_filter` VARCHAR(32) DEFAULT 'all', `start_date` VARCHAR(32) DEFAULT '', `end_date` VARCHAR(32) DEFAULT '', `payment_date` VARCHAR(32) DEFAULT '', `status` VARCHAR(32) DEFAULT 'finalized', `total_employees` INT NOT NULL DEFAULT 0, `total_payout` DECIMAL(15, 2) NOT NULL DEFAULT 0, `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `app_settings` (`id` VARCHAR(64) NOT NULL PRIMARY KEY, `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `late_validation_overrides` (`id` VARCHAR(64) NOT NULL PRIMARY KEY, `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `business_transactions` (`id` VARCHAR(128) NOT NULL PRIMARY KEY, `date` VARCHAR(32) DEFAULT '', `business_unit` VARCHAR(128) NOT NULL, `type` VARCHAR(32) NOT NULL, `category` VARCHAR(128) DEFAULT '', `amount` DECIMAL(15, 2) NOT NULL DEFAULT 0, `description` TEXT, `payment_method` VARCHAR(128) DEFAULT '', `reference_no` VARCHAR(128) DEFAULT '', `status` VARCHAR(32) DEFAULT 'completed', `source` VARCHAR(64) DEFAULT 'manual', `source_app` VARCHAR(255) DEFAULT '', `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `employee_savings_records` (`id` VARCHAR(128) NOT NULL PRIMARY KEY, `employee_id` VARCHAR(128) NOT NULL, `employee_name` VARCHAR(255) NOT NULL, `date` VARCHAR(32) DEFAULT '', `type` VARCHAR(32) NOT NULL, `amount` DECIMAL(15, 2) NOT NULL DEFAULT 0, `balance_after` DECIMAL(15, 2) NOT NULL DEFAULT 0, `source` VARCHAR(64) DEFAULT 'manual_deposit', `payroll_period_id` VARCHAR(128) DEFAULT NULL, `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS `app_checkpoints` (`id` VARCHAR(128) NOT NULL PRIMARY KEY, `timestamp` VARCHAR(64) NOT NULL, `trigger_type` VARCHAR(64) DEFAULT 'manual_save', `description` TEXT, `payload_json` LONGTEXT NOT NULL, `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        ];

        foreach ($ddlList as $sql) {
            try {
                $pdo->exec($sql);
            } catch (Throwable $ignored) {
                // Jika user MySQL tidak punya izin CREATE TABLE, tabel dianggap sudah di-import via phpMyAdmin schema.sql
            }
        }

        // Safe schema evolution for existing employees table (daily/monthly salary_type, gapok_hari, gapok_bulan)
        try {
            $colStmt = $pdo->query("SHOW COLUMNS FROM `employees`");
            $existingCols = [];
            while ($cRow = $colStmt->fetch()) {
                $existingCols[strtolower((string)($cRow['Field'] ?? ''))] = true;
            }
            if (!isset($existingCols['salary_type'])) {
                $pdo->exec("ALTER TABLE `employees` ADD COLUMN `salary_type` VARCHAR(16) DEFAULT 'daily' AFTER `pay_cycle_type`");
            }
            if (!isset($existingCols['gapok_hari'])) {
                $pdo->exec("ALTER TABLE `employees` ADD COLUMN `gapok_hari` DECIMAL(15, 2) NOT NULL DEFAULT 0 AFTER `salary_type`");
            }
            if (!isset($existingCols['gapok_bulan'])) {
                $pdo->exec("ALTER TABLE `employees` ADD COLUMN `gapok_bulan` DECIMAL(15, 2) NOT NULL DEFAULT 0 AFTER `gapok_hari`");
            }
            $dbState['employeesHasSalaryColumns'] = true;
        } catch (Throwable $ignored) {
            try {
                $checkStmt = $pdo->query("SHOW COLUMNS FROM `employees` LIKE 'salary_type'");
                $dbState['employeesHasSalaryColumns'] = ($checkStmt && $checkStmt->fetch()) ? true : false;
            } catch (Throwable $ignored2) {
                $dbState['employeesHasSalaryColumns'] = false;
            }
        }

        $dbState['pdo'] = $pdo;
        $dbState['mysqlConnected'] = true;
        $dbState['error'] = null;
    } catch (Throwable $e) {
        $dbState['pdo'] = null;
        $dbState['mysqlConnected'] = false;
        $dbState['error'] = $e->getMessage();
    }
}

initMysqlConnection($dbState);
$fallbackStore = loadFallbackStore($TABLE_MAP);

function getDbStatusPayload(array $dbState): array {
    return [
        'mode' => $dbState['mysqlConnected'] ? 'mysql' : 'local_fallback',
        'mysqlConfigured' => $dbState['mysqlConfigured'],
        'mysqlConnected' => $dbState['mysqlConnected'],
        'host' => $dbState['host'],
        'port' => $dbState['port'],
        'database' => $dbState['database'],
        'error' => $dbState['error'],
        'runtime' => 'php',
        'sseSupported' => false,
    ];
}

// =========================================================================
// Data Access Helpers (MySQL + Fallback Sync)
// =========================================================================
function clipStrPhp($val, int $maxLen): string {
    $s = ($val === null) ? '' : (string)$val;
    if (function_exists('mb_substr')) {
        return mb_substr($s, 0, $maxLen, 'UTF-8');
    }
    return substr($s, 0, $maxLen);
}

function safeJsonEncodePhp($data): string {
    $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $encoded = json_encode($data, $flags);
    if ($encoded === false) {
        $encoded = json_encode(['id' => $data['id'] ?? '', '_error' => json_last_error_msg()]);
    }
    return $encoded ?: '{}';
}

function toFiniteFloatPhp($val, float $fallback = 0.0): float {
    if (!is_numeric($val)) {
        return $fallback;
    }
    $f = (float)$val;
    return is_finite($f) ? $f : $fallback;
}

function upsertMysqlRow(PDO $pdo, string $collection, string $id, array $data, bool $employeesHasSalaryCols = false): void {
    $safeId = clipStrPhp($id, ($collection === 'appSettings' || $collection === 'lateValidationOverrides') ? 64 : 128);
    $data['id'] = $safeId;
    $payloadJson = safeJsonEncodePhp($data);

    switch ($collection) {
        case 'employees':
            if ($employeesHasSalaryCols) {
                $stmt = $pdo->prepare("INSERT INTO employees (id, no_id, name, division, position, pay_cycle_type, salary_type, gapok_hari, gapok_bulan, status, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE no_id=VALUES(no_id), name=VALUES(name), division=VALUES(division), position=VALUES(position), pay_cycle_type=VALUES(pay_cycle_type), salary_type=VALUES(salary_type), gapok_hari=VALUES(gapok_hari), gapok_bulan=VALUES(gapok_bulan), status=VALUES(status), payload_json=VALUES(payload_json)");
                $stmt->execute([
                    $safeId,
                    clipStrPhp($data['noId'] ?? '', 64),
                    clipStrPhp($data['name'] ?? '', 255),
                    clipStrPhp($data['division'] ?? 'PRODUKSI', 128),
                    clipStrPhp($data['position'] ?? 'Staff', 128),
                    clipStrPhp($data['payCycleType'] ?? 'date', 32),
                    clipStrPhp($data['salaryType'] ?? 'daily', 16),
                    toFiniteFloatPhp($data['gapokHari'] ?? 0),
                    toFiniteFloatPhp($data['gapokBulan'] ?? 0),
                    clipStrPhp($data['status'] ?? 'active', 32),
                    $payloadJson,
                ]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO employees (id, no_id, name, division, position, pay_cycle_type, status, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE no_id=VALUES(no_id), name=VALUES(name), division=VALUES(division), position=VALUES(position), pay_cycle_type=VALUES(pay_cycle_type), status=VALUES(status), payload_json=VALUES(payload_json)");
                $stmt->execute([
                    $safeId,
                    clipStrPhp($data['noId'] ?? '', 64),
                    clipStrPhp($data['name'] ?? '', 255),
                    clipStrPhp($data['division'] ?? 'PRODUKSI', 128),
                    clipStrPhp($data['position'] ?? 'Staff', 128),
                    clipStrPhp($data['payCycleType'] ?? 'date', 32),
                    clipStrPhp($data['status'] ?? 'active', 32),
                    $payloadJson,
                ]);
            }
            break;

        case 'kasbonRecords':
            $stmt = $pdo->prepare("INSERT INTO kasbon_records (id, employee_id, employee_name, date, type, total_amount, remaining_amount, status, invoice_no, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE employee_id=VALUES(employee_id), employee_name=VALUES(employee_name), date=VALUES(date), type=VALUES(type), total_amount=VALUES(total_amount), remaining_amount=VALUES(remaining_amount), status=VALUES(status), invoice_no=VALUES(invoice_no), payload_json=VALUES(payload_json)");
            $stmt->execute([
                $safeId,
                clipStrPhp($data['employeeId'] ?? '', 128),
                clipStrPhp($data['employeeName'] ?? '', 255),
                clipStrPhp($data['date'] ?? '', 32),
                clipStrPhp($data['type'] ?? 'kasbon', 64),
                toFiniteFloatPhp($data['totalAmount'] ?? 0),
                toFiniteFloatPhp($data['remainingAmount'] ?? $data['totalAmount'] ?? 0),
                clipStrPhp($data['status'] ?? 'pending', 32),
                isset($data['invoiceNo']) ? clipStrPhp($data['invoiceNo'], 128) : null,
                $payloadJson,
            ]);
            break;

        case 'kasbonDrafts':
            $stmt = $pdo->prepare("INSERT INTO kasbon_drafts (id, request_number, employee_id, employee_name, request_date, amount, status, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE request_number=VALUES(request_number), employee_id=VALUES(employee_id), employee_name=VALUES(employee_name), request_date=VALUES(request_date), amount=VALUES(amount), status=VALUES(status), payload_json=VALUES(payload_json)");
            $stmt->execute([
                $safeId,
                clipStrPhp($data['requestNumber'] ?? '', 128),
                clipStrPhp($data['employeeId'] ?? '', 128),
                clipStrPhp($data['employeeName'] ?? '', 255),
                clipStrPhp($data['requestDate'] ?? '', 32),
                toFiniteFloatPhp($data['amount'] ?? 0),
                clipStrPhp($data['status'] ?? 'menunggu_acc', 32),
                $payloadJson,
            ]);
            break;

        case 'bonusRecords':
            $stmt = $pdo->prepare("INSERT INTO bonus_records (id, employee_id, employee_name, date, type, amount, status, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE employee_id=VALUES(employee_id), employee_name=VALUES(employee_name), date=VALUES(date), type=VALUES(type), amount=VALUES(amount), status=VALUES(status), payload_json=VALUES(payload_json)");
            $stmt->execute([
                $safeId,
                clipStrPhp($data['employeeId'] ?? '', 128),
                clipStrPhp($data['employeeName'] ?? '', 255),
                clipStrPhp($data['date'] ?? '', 32),
                clipStrPhp($data['type'] ?? 'tunai', 32),
                toFiniteFloatPhp($data['amount'] ?? 0),
                clipStrPhp($data['status'] ?? 'pending', 32),
                $payloadJson,
            ]);
            break;

        case 'pengajianSessions':
            $stmt = $pdo->prepare("INSERT INTO pengajian_sessions (id, date, title, total_peserta, total_ustadz, total_nominal_non_tunai, status, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE date=VALUES(date), title=VALUES(title), total_peserta=VALUES(total_peserta), total_ustadz=VALUES(total_ustadz), total_nominal_non_tunai=VALUES(total_nominal_non_tunai), status=VALUES(status), payload_json=VALUES(payload_json)");
            $stmt->execute([
                $safeId,
                clipStrPhp($data['date'] ?? '', 32),
                clipStrPhp($data['title'] ?? '', 255),
                (int)round(toFiniteFloatPhp($data['totalPeserta'] ?? 0)),
                (int)round(toFiniteFloatPhp($data['totalUstadz'] ?? 0)),
                toFiniteFloatPhp($data['totalNominalNonTunai'] ?? 0),
                clipStrPhp($data['status'] ?? 'active', 32),
                $payloadJson,
            ]);
            break;

        case 'rawLogs':
            $stmt = $pdo->prepare("INSERT INTO raw_logs (id, employee_name, user_id, timestamp, status, department, device, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE employee_name=VALUES(employee_name), user_id=VALUES(user_id), timestamp=VALUES(timestamp), status=VALUES(status), department=VALUES(department), device=VALUES(device), payload_json=VALUES(payload_json)");
            $stmt->execute([
                $safeId,
                clipStrPhp($data['employeeName'] ?? '', 255),
                clipStrPhp($data['userId'] ?? '', 64),
                clipStrPhp($data['timestamp'] ?? '', 64),
                clipStrPhp($data['status'] ?? '', 64),
                clipStrPhp($data['department'] ?? '', 128),
                clipStrPhp($data['device'] ?? '', 128),
                $payloadJson,
            ]);
            break;

        case 'payrollPeriods':
            $stmt = $pdo->prepare("INSERT INTO payroll_periods (id, name, pay_cycle_filter, start_date, end_date, payment_date, status, total_employees, total_payout, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), pay_cycle_filter=VALUES(pay_cycle_filter), start_date=VALUES(start_date), end_date=VALUES(end_date), payment_date=VALUES(payment_date), status=VALUES(status), total_employees=VALUES(total_employees), total_payout=VALUES(total_payout), payload_json=VALUES(payload_json)");
            $stmt->execute([
                $safeId,
                clipStrPhp($data['name'] ?? '', 255),
                clipStrPhp($data['payCycleFilter'] ?? 'all', 32),
                clipStrPhp($data['startDate'] ?? '', 32),
                clipStrPhp($data['endDate'] ?? '', 32),
                clipStrPhp($data['paymentDate'] ?? '', 32),
                clipStrPhp($data['status'] ?? 'finalized', 32),
                (int)round(toFiniteFloatPhp($data['totalEmployees'] ?? 0)),
                toFiniteFloatPhp($data['totalPayout'] ?? 0),
                $payloadJson,
            ]);
            break;

        case 'appSettings':
            $stmt = $pdo->prepare("INSERT INTO app_settings (id, payload_json) VALUES (?, ?) ON DUPLICATE KEY UPDATE payload_json=VALUES(payload_json)");
            $stmt->execute([$safeId, $payloadJson]);
            break;

        case 'lateValidationOverrides':
            $stmt = $pdo->prepare("INSERT INTO late_validation_overrides (id, payload_json) VALUES (?, ?) ON DUPLICATE KEY UPDATE payload_json=VALUES(payload_json)");
            $stmt->execute([$safeId, $payloadJson]);
            break;

        case 'businessTransactions':
            $stmt = $pdo->prepare("INSERT INTO business_transactions (id, date, business_unit, type, category, amount, description, payment_method, reference_no, status, source, source_app, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE date=VALUES(date), business_unit=VALUES(business_unit), type=VALUES(type), category=VALUES(category), amount=VALUES(amount), description=VALUES(description), payment_method=VALUES(payment_method), reference_no=VALUES(reference_no), status=VALUES(status), source=VALUES(source), source_app=VALUES(source_app), payload_json=VALUES(payload_json)");
            $stmt->execute([
                $safeId,
                clipStrPhp($data['date'] ?? '', 32),
                clipStrPhp($data['businessUnit'] ?? 'ERVO PAYROLL', 128),
                clipStrPhp($data['type'] ?? 'income', 32),
                clipStrPhp($data['category'] ?? '', 128),
                toFiniteFloatPhp($data['amount'] ?? 0),
                (string)($data['description'] ?? ''),
                clipStrPhp($data['paymentMethod'] ?? '', 128),
                clipStrPhp($data['referenceNo'] ?? '', 128),
                clipStrPhp($data['status'] ?? 'completed', 32),
                clipStrPhp($data['source'] ?? 'manual', 64),
                clipStrPhp($data['sourceApp'] ?? '', 255),
                $payloadJson,
            ]);
            break;

        case 'employeeSavingsRecords':
            $stmt = $pdo->prepare("INSERT INTO employee_savings_records (id, employee_id, employee_name, date, type, amount, balance_after, source, payroll_period_id, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE employee_id=VALUES(employee_id), employee_name=VALUES(employee_name), date=VALUES(date), type=VALUES(type), amount=VALUES(amount), balance_after=VALUES(balance_after), source=VALUES(source), payroll_period_id=VALUES(payroll_period_id), payload_json=VALUES(payload_json)");
            $stmt->execute([
                $safeId,
                clipStrPhp($data['employeeId'] ?? '', 128),
                clipStrPhp($data['employeeName'] ?? '', 255),
                clipStrPhp($data['date'] ?? '', 32),
                clipStrPhp($data['type'] ?? 'setor', 32),
                toFiniteFloatPhp($data['amount'] ?? 0),
                toFiniteFloatPhp($data['balanceAfter'] ?? 0),
                clipStrPhp($data['source'] ?? 'manual_deposit', 64),
                isset($data['payrollPeriodId']) ? clipStrPhp($data['payrollPeriodId'], 128) : null,
                $payloadJson,
            ]);
            break;

        case 'appCheckpoints':
            $stmt = $pdo->prepare("INSERT INTO app_checkpoints (id, timestamp, trigger_type, description, payload_json) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE timestamp=VALUES(timestamp), trigger_type=VALUES(trigger_type), description=VALUES(description), payload_json=VALUES(payload_json)");
            $stmt->execute([
                $safeId,
                clipStrPhp($data['timestamp'] ?? '', 64),
                clipStrPhp($data['trigger'] ?? 'manual_save', 64),
                (string)($data['description'] ?? ''),
                $payloadJson,
            ]);
            break;
    }
}

function getCollectionData(array $dbState, array $fallbackStore, array $tableMap, string $collection): array {
    $table = $TABLE_MAP_VAL = $tableMap[$collection];
    if ($dbState['mysqlConnected'] && $dbState['pdo'] instanceof PDO) {
        try {
            $stmt = $dbState['pdo']->query("SELECT payload_json FROM `{$table}`");
            $items = [];
            while ($row = $stmt->fetch()) {
                $decoded = json_decode((string)$row['payload_json'], true);
                if (is_array($decoded)) {
                    $items[] = $decoded;
                }
            }
            return $items;
        } catch (Throwable $ignored) {
        }
    }
    return array_values($fallbackStore[$collection] ?? []);
}

function getDocumentData(array $dbState, array $fallbackStore, array $tableMap, string $collection, string $id): ?array {
    $table = $tableMap[$collection];
    if ($dbState['mysqlConnected'] && $dbState['pdo'] instanceof PDO) {
        try {
            $stmt = $dbState['pdo']->prepare("SELECT payload_json FROM `{$table}` WHERE id = ? LIMIT 1");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            if ($row) {
                $decoded = json_decode((string)$row['payload_json'], true);
                return is_array($decoded) ? $decoded : null;
            }
            return null;
        } catch (Throwable $ignored) {
        }
    }
    $item = $fallbackStore[$collection][$id] ?? null;
    return is_array($item) ? $item : null;
}

function upsertDocumentData(array $dbState, array &$fallbackStore, string $collection, string $id, array $data): void {
    $cleanId = trim($id);
    if ($cleanId === '') {
        return;
    }
    $data['id'] = $cleanId;
    $fallbackStore[$collection][$cleanId] = $data;
    saveFallbackStore($fallbackStore);

    if ($dbState['mysqlConnected'] && $dbState['pdo'] instanceof PDO) {
        upsertMysqlRow($dbState['pdo'], $collection, $cleanId, $data, !empty($dbState['employeesHasSalaryColumns']));
    }
}

function batchUpsertData(array $dbState, array &$fallbackStore, string $collection, array $items): int {
    if (empty($items)) {
        return 0;
    }
    $cleanItems = [];
    $idx = 0;
    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }
        $rawId = $item['id'] ?? $item['_id'] ?? $item['uid'] ?? $item['docId'] ?? '';
        $cleanId = trim((string)$rawId);
        if ($cleanId === '') {
            $cleanId = $collection . '-auto-' . base_convert((string)time(), 10, 36) . '-' . $idx;
        }
        $cleanId = clipStrPhp($cleanId, 128);
        $item['id'] = $cleanId;
        $fallbackStore[$collection][$cleanId] = $item;
        $cleanItems[] = ['id' => $cleanId, 'data' => $item];
        $idx++;
    }
    saveFallbackStore($fallbackStore);

    if ($dbState['mysqlConnected'] && $dbState['pdo'] instanceof PDO && !empty($cleanItems)) {
        $pdo = $dbState['pdo'];
        $hasSalaryCols = !empty($dbState['employeesHasSalaryColumns']);
        foreach (array_chunk($cleanItems, 100) as $chunk) {
            $pdo->beginTransaction();
            try {
                foreach ($chunk as $entry) {
                    upsertMysqlRow($pdo, $collection, $entry['id'], $entry['data'], $hasSalaryCols);
                }
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $e;
            }
        }
    }
    return count($cleanItems);
}

function deleteDocumentData(array $dbState, array &$fallbackStore, array $tableMap, string $collection, string $id): void {
    $cleanId = trim($id);
    if ($cleanId === '') {
        return;
    }
    unset($fallbackStore[$collection][$cleanId]);
    saveFallbackStore($fallbackStore);

    if ($dbState['mysqlConnected'] && $dbState['pdo'] instanceof PDO) {
        $table = $tableMap[$collection];
        $stmt = $dbState['pdo']->prepare("DELETE FROM `{$table}` WHERE id = ?");
        $stmt->execute([$cleanId]);
    }
}

function batchDeleteData(array $dbState, array &$fallbackStore, array $tableMap, string $collection, array $ids): void {
    $validIds = array_values(array_filter(array_map(fn($x) => trim((string)$x), $ids), fn($x) => $x !== ''));
    if (empty($validIds)) {
        return;
    }
    foreach ($validIds as $id) {
        unset($fallbackStore[$collection][$id]);
    }
    saveFallbackStore($fallbackStore);

    if ($dbState['mysqlConnected'] && $dbState['pdo'] instanceof PDO) {
        $table = $tableMap[$collection];
        $placeholders = implode(',', array_fill(0, count($validIds), '?'));
        $stmt = $dbState['pdo']->prepare("DELETE FROM `{$table}` WHERE id IN ({$placeholders})");
        $stmt->execute($validIds);
    }
}

function clearCollectionData(array $dbState, array &$fallbackStore, array $tableMap, string $collection): void {
    $fallbackStore[$collection] = [];
    saveFallbackStore($fallbackStore);

    if ($dbState['mysqlConnected'] && $dbState['pdo'] instanceof PDO) {
        $table = $tableMap[$collection];
        $dbState['pdo']->exec("DELETE FROM `{$table}`");
    }
}

function deleteTxByRefNo(array $dbState, array &$fallbackStore, string $refNo): array {
    $cleanRef = trim($refNo);
    if ($cleanRef === '') {
        return [];
    }
    $deletedIds = [];
    foreach ($fallbackStore['businessTransactions'] as $id => $tx) {
        if (trim((string)($tx['referenceNo'] ?? '')) === $cleanRef) {
            $deletedIds[] = (string)$id;
            unset($fallbackStore['businessTransactions'][$id]);
        }
    }
    if (!empty($deletedIds)) {
        saveFallbackStore($fallbackStore);
    }

    if ($dbState['mysqlConnected'] && $dbState['pdo'] instanceof PDO) {
        $pdo = $dbState['pdo'];
        $stmt = $pdo->prepare("SELECT id FROM business_transactions WHERE reference_no = ?");
        $stmt->execute([$cleanRef]);
        while ($row = $stmt->fetch()) {
            if (!in_array((string)$row['id'], $deletedIds, true)) {
                $deletedIds[] = (string)$row['id'];
            }
        }
        $delStmt = $pdo->prepare("DELETE FROM business_transactions WHERE reference_no = ?");
        $delStmt->execute([$cleanRef]);
    }

    return $deletedIds;
}

function parseMoneyAmount($val): float {
    if ($val === null || $val === '') {
        return 0.0;
    }
    if (is_int($val) || is_float($val)) {
        return abs((float)$val);
    }
    $str = trim((string)$val);
    if ($str === '') {
        return 0.0;
    }
    $cleaned = preg_replace('/[rRpP\s]/', '', $str) ?? '';
    if (strpos($cleaned, '.') !== false && strpos($cleaned, ',') !== false) {
        $cleaned = str_replace(',', '.', str_replace('.', '', $cleaned));
    } elseif (strpos($cleaned, '.') !== false) {
        $parts = explode('.', $cleaned);
        if (count($parts) > 2 || (count($parts) === 2 && strlen($parts[1]) === 3)) {
            $cleaned = str_replace('.', '', $cleaned);
        }
    } elseif (strpos($cleaned, ',') !== false) {
        $parts = explode(',', $cleaned);
        if (count($parts) > 2 || (count($parts) === 2 && strlen($parts[1]) === 3)) {
            $cleaned = str_replace(',', '', $cleaned);
        } else {
            $cleaned = str_replace(',', '.', $cleaned);
        }
    }
    return is_numeric($cleaned) ? abs((float)$cleaned) : 0.0;
}

// =========================================================================
// Router Dispatch
// =========================================================================
$route = resolveRoute();
$parts = $route === '' ? [] : explode('/', $route);

try {
    // 1. Health Check
    if ($route === 'health' && $method === 'GET') {
        $cal = loadCalendarFile();
        $status = getDbStatusPayload($dbState);
        sendJson([
            'status' => 'ok',
            'runtime' => 'php',
            'sseSupported' => false,
            'databaseMode' => $status['mode'],
            'mysqlConfigured' => $status['mysqlConfigured'],
            'mysqlConnected' => $status['mysqlConnected'],
            'host' => $status['host'],
            'database' => $status['database'],
            'error' => $status['error'],
            'totalRecords' => count($cal['records']),
            'activeSSEClients' => 0,
            'lastUpdated' => $cal['lastUpdated'],
        ]);
    }

    // 1b. Serve schema.sql download
    if ($route === 'schema.sql' && $method === 'GET') {
        $schemaFile = __DIR__ . '/schema.sql';
        if (!file_exists($schemaFile)) {
            http_response_code(404);
            exit('-- schema.sql not found');
        }
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="ervo_payroll_phpmyadmin_schema.sql"');
        readfile($schemaFile);
        exit;
    }

    // 2. Database Bootstrap
    if ($route === 'db/bootstrap' && $method === 'GET') {
        $settingsDoc = getDocumentData($dbState, $fallbackStore, $TABLE_MAP, 'appSettings', 'general');
        $lateDoc = getDocumentData($dbState, $fallbackStore, $TABLE_MAP, 'lateValidationOverrides', 'overrides');
        $notesDoc = getDocumentData($dbState, $fallbackStore, $TABLE_MAP, 'lateValidationOverrides', 'attendance_notes');
        $calDoc = getDocumentData($dbState, $fallbackStore, $TABLE_MAP, 'lateValidationOverrides', 'calendar_records');
        $holDoc = getDocumentData($dbState, $fallbackStore, $TABLE_MAP, 'lateValidationOverrides', 'company_holidays');

        sendJson([
            'status' => getDbStatusPayload($dbState),
            'employees' => getCollectionData($dbState, $fallbackStore, $TABLE_MAP, 'employees'),
            'kasbonRecords' => getCollectionData($dbState, $fallbackStore, $TABLE_MAP, 'kasbonRecords'),
            'kasbonDrafts' => getCollectionData($dbState, $fallbackStore, $TABLE_MAP, 'kasbonDrafts'),
            'bonusRecords' => getCollectionData($dbState, $fallbackStore, $TABLE_MAP, 'bonusRecords'),
            'pengajianSessions' => getCollectionData($dbState, $fallbackStore, $TABLE_MAP, 'pengajianSessions'),
            'rawLogs' => getCollectionData($dbState, $fallbackStore, $TABLE_MAP, 'rawLogs'),
            'payrollPeriods' => getCollectionData($dbState, $fallbackStore, $TABLE_MAP, 'payrollPeriods'),
            'settings' => $settingsDoc,
            'lateOverrides' => is_array($lateDoc['overrides'] ?? null) ? $lateDoc['overrides'] : (object)[],
            'attendanceNotes' => is_array($notesDoc['notes'] ?? null) ? $notesDoc['notes'] : (object)[],
            'calendarRecords' => is_array($calDoc['records'] ?? null) ? $calDoc['records'] : (object)[],
            'companyHolidays' => is_array($holDoc['holidays'] ?? null) ? $holDoc['holidays'] : [],
            'businessTransactions' => getCollectionData($dbState, $fallbackStore, $TABLE_MAP, 'businessTransactions'),
            'savingsRecords' => getCollectionData($dbState, $fallbackStore, $TABLE_MAP, 'employeeSavingsRecords'),
            'appCheckpoints' => getCollectionData($dbState, $fallbackStore, $TABLE_MAP, 'appCheckpoints'),
        ]);
    }

    // 2b. Seed Database
    if ($route === 'db/seed' && $method === 'POST') {
        $data = getJsonBody();
        $savedCounts = [];
        if (!empty($data['employees']) && is_array($data['employees'])) {
            $savedCounts['employees'] = batchUpsertData($dbState, $fallbackStore, 'employees', $data['employees']);
        }
        if (!empty($data['kasbonRecords']) && is_array($data['kasbonRecords'])) {
            $savedCounts['kasbonRecords'] = batchUpsertData($dbState, $fallbackStore, 'kasbonRecords', $data['kasbonRecords']);
        }
        if (!empty($data['kasbonDrafts']) && is_array($data['kasbonDrafts'])) {
            $savedCounts['kasbonDrafts'] = batchUpsertData($dbState, $fallbackStore, 'kasbonDrafts', $data['kasbonDrafts']);
        }
        if (!empty($data['bonusRecords']) && is_array($data['bonusRecords'])) {
            $savedCounts['bonusRecords'] = batchUpsertData($dbState, $fallbackStore, 'bonusRecords', $data['bonusRecords']);
        }
        if (!empty($data['pengajianSessions']) && is_array($data['pengajianSessions'])) {
            $savedCounts['pengajianSessions'] = batchUpsertData($dbState, $fallbackStore, 'pengajianSessions', $data['pengajianSessions']);
        }
        if (!empty($data['rawLogs']) && is_array($data['rawLogs'])) {
            $savedCounts['rawLogs'] = batchUpsertData($dbState, $fallbackStore, 'rawLogs', $data['rawLogs']);
        }
        if (!empty($data['payrollPeriods']) && is_array($data['payrollPeriods'])) {
            $savedCounts['payrollPeriods'] = batchUpsertData($dbState, $fallbackStore, 'payrollPeriods', $data['payrollPeriods']);
        }
        if (!empty($data['savingsRecords']) && is_array($data['savingsRecords'])) {
            $savedCounts['savingsRecords'] = batchUpsertData($dbState, $fallbackStore, 'employeeSavingsRecords', $data['savingsRecords']);
        }
        if (!empty($data['businessTransactions']) && is_array($data['businessTransactions'])) {
            $savedCounts['businessTransactions'] = batchUpsertData($dbState, $fallbackStore, 'businessTransactions', $data['businessTransactions']);
        }
        if (!empty($data['settings']) && is_array($data['settings'])) {
            upsertDocumentData($dbState, $fallbackStore, 'appSettings', 'general', $data['settings']);
            $savedCounts['settings'] = 1;
        }
        if (isset($data['lateValidationOverrides']) && is_array($data['lateValidationOverrides'])) {
            upsertDocumentData($dbState, $fallbackStore, 'lateValidationOverrides', 'overrides', [
                'id' => 'overrides',
                'overrides' => $data['lateValidationOverrides'],
            ]);
            $savedCounts['lateValidationOverrides'] = count($data['lateValidationOverrides']);
        }
        if (isset($data['attendanceNotes']) && is_array($data['attendanceNotes'])) {
            upsertDocumentData($dbState, $fallbackStore, 'lateValidationOverrides', 'attendance_notes', [
                'id' => 'attendance_notes',
                'notes' => $data['attendanceNotes'],
            ]);
            $savedCounts['attendanceNotes'] = count($data['attendanceNotes']);
        }
        if (isset($data['calendarRecords']) && is_array($data['calendarRecords'])) {
            upsertDocumentData($dbState, $fallbackStore, 'lateValidationOverrides', 'calendar_records', [
                'id' => 'calendar_records',
                'records' => $data['calendarRecords'],
            ]);
            $savedCounts['calendarRecords'] = count($data['calendarRecords']);
        }
        if (isset($data['companyHolidays']) && is_array($data['companyHolidays'])) {
            upsertDocumentData($dbState, $fallbackStore, 'lateValidationOverrides', 'company_holidays', [
                'id' => 'company_holidays',
                'holidays' => $data['companyHolidays'],
            ]);
            $savedCounts['companyHolidays'] = count($data['companyHolidays']);
        }
        sendJson([
            'success' => true,
            'status' => getDbStatusPayload($dbState),
            'savedCounts' => $savedCounts,
        ]);
    }

    // 2c. Clear All Transaction Tables
    if ($route === 'db/clear-transactions' && $method === 'POST') {
        $toClear = [
            'employees', 'kasbonRecords', 'kasbonDrafts', 'bonusRecords',
            'pengajianSessions', 'rawLogs', 'payrollPeriods',
            'lateValidationOverrides', 'businessTransactions', 'employeeSavingsRecords',
        ];
        foreach ($toClear as $col) {
            clearCollectionData($dbState, $fallbackStore, $TABLE_MAP, $col);
        }
        sendJson(['success' => true]);
    }

    // 3. Generic Collection Routes: db/{collection}[/...]
    if (($parts[0] ?? '') === 'db' && isset($parts[1])) {
        $collection = $parts[1];
        if (!isset($TABLE_MAP[$collection])) {
            sendJson(['success' => false, 'error' => "Koleksi tidak dikenal: {$collection}"], 400);
        }

        // POST db/{collection}/batch-delete
        if (($parts[2] ?? '') === 'batch-delete' && $method === 'POST') {
            $body = getJsonBody();
            $ids = is_array($body['ids'] ?? null) ? $body['ids'] : [];
            batchDeleteData($dbState, $fallbackStore, $TABLE_MAP, $collection, $ids);
            sendJson(['success' => true, 'deletedCount' => count($ids)]);
        }

        // Document-level: db/{collection}/{id}
        if (isset($parts[2]) && $parts[2] !== '') {
            $docId = urldecode($parts[2]);
            if ($method === 'GET') {
                $item = getDocumentData($dbState, $fallbackStore, $TABLE_MAP, $collection, $docId);
                sendJson(['success' => true, 'item' => $item]);
            }
            if ($method === 'PUT' || $method === 'POST') {
                $body = getJsonBody();
                upsertDocumentData($dbState, $fallbackStore, $collection, $docId, $body);
                sendJson(['success' => true, 'id' => $docId]);
            }
            if ($method === 'DELETE') {
                deleteDocumentData($dbState, $fallbackStore, $TABLE_MAP, $collection, $docId);
                sendJson(['success' => true, 'id' => $docId]);
            }
        }

        // Collection-level: db/{collection}
        if ($method === 'GET') {
            $items = getCollectionData($dbState, $fallbackStore, $TABLE_MAP, $collection);
            sendJson(['success' => true, 'items' => $items]);
        }
        if ($method === 'POST') {
            $body = getJsonBody();
            if (isset($body['items']) && is_array($body['items'])) {
                batchUpsertData($dbState, $fallbackStore, $collection, $body['items']);
                sendJson(['success' => true, 'count' => count($body['items'])]);
            }
            $id = trim((string)($body['id'] ?? ''));
            if ($id === '') {
                sendJson(['success' => false, 'error' => 'Field id wajib disertakan'], 400);
            }
            upsertDocumentData($dbState, $fallbackStore, $collection, $id, $body);
            sendJson(['success' => true, 'id' => $id]);
        }
        if ($method === 'DELETE') {
            clearCollectionData($dbState, $fallbackStore, $TABLE_MAP, $collection);
            sendJson(['success' => true]);
        }
    }

    // 4. Calendar Sync Routes
    if ($route === 'calendar-sync') {
        if ($method === 'GET') {
            $cal = loadCalendarFile();
            $dbCal = getDocumentData($dbState, $fallbackStore, $TABLE_MAP, 'lateValidationOverrides', 'calendar_records');
            $dbHol = getDocumentData($dbState, $fallbackStore, $TABLE_MAP, 'lateValidationOverrides', 'company_holidays');

            $records = !empty($cal['records']) ? $cal['records'] : (is_array($dbCal['records'] ?? null) ? $dbCal['records'] : []);
            $holidays = !empty($cal['holidays']) ? $cal['holidays'] : (is_array($dbHol['holidays'] ?? null) ? $dbHol['holidays'] : []);

            sendJson([
                'success' => true,
                'records' => !empty($records) ? $records : (object)[],
                'holidays' => $holidays,
                'lastUpdated' => $cal['lastUpdated'],
                'totalRecords' => count($records),
            ]);
        }

        if ($method === 'POST') {
            $body = getJsonBody();
            $cal = loadCalendarFile();
            $modified = false;

            if (isset($body['records']) && is_array($body['records'])) {
                if (!empty($body['fullReplace'])) {
                    $cal['records'] = $body['records'];
                    $modified = true;
                } else {
                    foreach ($body['records'] as $key => $val) {
                        if (is_array($val)) {
                            $existing = is_array($cal['records'][$key] ?? null) ? $cal['records'][$key] : [];
                            $cal['records'][$key] = array_merge($existing, $val);
                            $modified = true;
                        }
                    }
                }
                upsertDocumentData($dbState, $fallbackStore, 'lateValidationOverrides', 'calendar_records', [
                    'id' => 'calendar_records',
                    'records' => $cal['records'],
                ]);
            }

            if (isset($body['holidays']) && is_array($body['holidays'])) {
                $cal['holidays'] = $body['holidays'];
                $modified = true;
                upsertDocumentData($dbState, $fallbackStore, 'lateValidationOverrides', 'company_holidays', [
                    'id' => 'company_holidays',
                    'holidays' => $cal['holidays'],
                ]);
            }

            if ($modified) {
                $cal['lastUpdated'] = gmdate('c');
                saveCalendarFile($cal);
            }

            sendJson([
                'success' => true,
                'totalRecords' => count($cal['records']),
                'lastUpdated' => $cal['lastUpdated'],
            ]);
        }
    }

    // 5. Business Transactions Webhook Routes (ERVO STORE & ERVO SUBLIME)
    if ($route === 'transactions/delete' && $method === 'POST') {
        $body = getJsonBody();
        $deletedCount = 0;

        if (!empty($body['id'])) {
            deleteDocumentData($dbState, $fallbackStore, $TABLE_MAP, 'businessTransactions', (string)$body['id']);
            $deletedCount++;
        }
        if (!empty($body['ids']) && is_array($body['ids'])) {
            batchDeleteData($dbState, $fallbackStore, $TABLE_MAP, 'businessTransactions', $body['ids']);
            $deletedCount += count($body['ids']);
        }
        if (!empty($body['referenceNo'])) {
            $removed = deleteTxByRefNo($dbState, $fallbackStore, (string)$body['referenceNo']);
            $deletedCount += count($removed);
        }

        sendJson([
            'success' => true,
            'message' => "Berhasil menghapus {$deletedCount} transaksi dari ERVO Payroll Hub",
            'deletedCount' => $deletedCount,
        ]);
    }

    if (($parts[0] ?? '') === 'transactions') {
        if (isset($parts[1]) && $parts[1] !== '' && $method === 'DELETE') {
            $txId = urldecode($parts[1]);
            deleteDocumentData($dbState, $fallbackStore, $TABLE_MAP, 'businessTransactions', $txId);
            sendJson(['success' => true, 'message' => "Transaksi {$txId} berhasil dihapus dari Database"]);
        }

        if ($method === 'GET') {
            sendJson([
                'status' => 'ok',
                'message' => 'Webhook Transaksi Realtime ERVO Payroll Hub (PHP + MySQL / phpMyAdmin) siap menerima POST request dari ERVO STORE & ERVO SUBLIME.',
            ]);
        }

        if ($method === 'DELETE') {
            $body = getJsonBody();
            $refNo = $_GET['referenceNo'] ?? $_GET['refNo'] ?? ($body['referenceNo'] ?? null);
            $txId = $_GET['id'] ?? ($body['id'] ?? null);

            if ($txId) {
                deleteDocumentData($dbState, $fallbackStore, $TABLE_MAP, 'businessTransactions', (string)$txId);
                sendJson(['success' => true, 'message' => "Transaksi ID {$txId} berhasil dihapus"]);
            }
            if ($refNo) {
                $removed = deleteTxByRefNo($dbState, $fallbackStore, (string)$refNo);
                sendJson(['success' => true, 'message' => 'Berhasil menghapus ' . count($removed) . " transaksi dengan referensi {$refNo}"]);
            }
            sendJson(['success' => false, 'error' => 'Harap sertakan parameter id atau referenceNo'], 400);
        }

        if ($method === 'POST') {
            $body = getJsonBody();
            $rawList = [];
            if (array_is_list($body)) {
                $rawList = $body;
            } elseif (isset($body['transactions']) && is_array($body['transactions'])) {
                $rawList = $body['transactions'];
            } elseif (!empty($body)) {
                $rawList = [$body];
            }

            if (empty($rawList)) {
                sendJson(['success' => false, 'error' => 'Payload transaksi kosong'], 400);
            }

            $savedDocs = [];
            $deletedDocs = [];

            foreach ($rawList as $item) {
                if (!is_array($item)) {
                    continue;
                }
                $action = strtolower((string)($item['action'] ?? $item['event'] ?? ''));
                if (in_array($action, ['delete', 'remove', 'destroy'], true)) {
                    $targetId = $item['id'] ?? null;
                    $targetRef = $item['referenceNo'] ?? $item['refNo'] ?? $item['invoiceNumber'] ?? $item['noInvoice'] ?? null;
                    if ($targetId) {
                        deleteDocumentData($dbState, $fallbackStore, $TABLE_MAP, 'businessTransactions', (string)$targetId);
                        $deletedDocs[] = (string)$targetId;
                    } elseif ($targetRef) {
                        $removed = deleteTxByRefNo($dbState, $fallbackStore, (string)$targetRef);
                        $deletedDocs = array_merge($deletedDocs, $removed);
                    }
                    continue;
                }

                $businessUnit = $item['businessUnit'] ?? '';
                $rawAmount = $item['amount'] ?? $item['total'] ?? $item['grandTotal'] ?? $item['totalAmount'] ?? $item['totalBayar'] ?? $item['nominal'] ?? $item['price'] ?? $item['tagihan'] ?? 0;
                $amount = parseMoneyAmount($rawAmount);
                $referenceNo = $item['referenceNo'] ?? $item['refNo'] ?? $item['invoiceNumber'] ?? null;

                if ($businessUnit === '' && $amount === 0.0 && empty($item['id']) && empty($referenceNo)) {
                    continue;
                }

                $unitUpper = strtoupper((string)$businessUnit);
                $isStore = strpos($unitUpper, 'STORE') !== false || strpos($unitUpper, 'POS') !== false;
                $unit = $isStore ? 'ERVO STORE' : 'ERVO SUBLIME';
                $prefix = $isStore ? 'str-' : 'sub-';

                $refClean = $referenceNo ? (preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$referenceNo) ?? '') : '';
                $txId = !empty($item['id']) ? (string)$item['id'] : ($refClean !== '' ? ($prefix . $refClean) : ('tx-' . time() . '-' . substr(md5((string)mt_rand()), 0, 5)));

                $rawType = (string)($item['type'] ?? 'income');
                $txType = ($rawType === 'expense' || stripos($rawType, 'keluar') !== false) ? 'expense' : 'income';

                $txDoc = [
                    'id' => $txId,
                    'date' => (string)($item['date'] ?? $item['tanggal'] ?? date('Y-m-d')),
                    'businessUnit' => $unit,
                    'type' => $txType,
                    'category' => (string)($item['category'] ?? ($txType === 'expense' ? 'Operasional' : ($isStore ? 'Penjualan Kasir' : 'Jasa Cetak Sublime'))),
                    'amount' => $amount,
                    'description' => (string)($item['description'] ?? $item['keterangan'] ?? $item['item'] ?? "Transaksi {$unit}"),
                    'paymentMethod' => (string)($item['paymentMethod'] ?? $item['metodeBayar'] ?? 'Non-Tunai'),
                    'referenceNo' => (string)($referenceNo ?? ('REF-' . substr((string)time(), -6))),
                    'status' => 'completed',
                    'source' => 'api_sync',
                    'sourceApp' => (string)($item['sourceApp'] ?? ($_SERVER['HTTP_ORIGIN'] ?? 'External App')),
                    'notes' => (string)($item['notes'] ?? 'Diterima via HTTP Webhook API (PHP + MySQL)'),
                    'createdAt' => (string)($item['createdAt'] ?? gmdate('c')),
                    'updatedAt' => gmdate('c'),
                ];

                $savedDocs[] = $txDoc;
            }

            if (!empty($savedDocs)) {
                batchUpsertData($dbState, $fallbackStore, 'businessTransactions', $savedDocs);
            }

            sendJson([
                'success' => true,
                'message' => 'Berhasil memproses sinkronisasi: ' . count($savedDocs) . ' disimpan, ' . count($deletedDocs) . ' dihapus',
                'totalSaved' => count($savedDocs),
                'totalDeleted' => count($deletedDocs),
                'transactions' => $savedDocs,
            ]);
        }
    }

    sendJson(['success' => false, 'error' => "Endpoint tidak ditemukan: {$method} /api/{$route}"], 404);
} catch (Throwable $e) {
    sendJson([
        'success' => false,
        'error' => $e->getMessage() ?: 'Terjadi kesalahan internal server PHP API',
    ], 500);
}
