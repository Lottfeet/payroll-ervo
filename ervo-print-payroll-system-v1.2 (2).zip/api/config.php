<?php
/**
 * Konfigurasi Database MySQL / phpMyAdmin untuk cPanel Shared Hosting (Non-Node.js)
 *
 * Cara Pengaturan di cPanel:
 * 1. Salin / ubah nama file ini menjadi `config.php` di dalam folder `api/`.
 * 2. Isi DB_NAME, DB_USER, dan DB_PASS sesuai database yang Anda buat di menu
 *    "MySQL Databases" di cPanel Anda.
 * 3. Pastikan sudah mengimpor file `schema.sql` ke database tersebut melalui phpMyAdmin.
 */

return [
   'DB_HOST' => 'localhost',
    'DB_PORT' => 3306,
    'DB_NAME' => 'hump6894_ervopayroll',
    'DB_USER' => 'hump6894_ervopayroll',
    'DB_PASS' => '10203040@payroll',
    'DB_CHARSET' => 'utf8mb4',
];
